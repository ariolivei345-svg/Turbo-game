package com.turbo.game

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.os.StatFs
import android.os.storage.StorageManager
import android.provider.Settings
import org.json.JSONObject

/** Lê boolean de um JSON aceitando true/false, 1/0 e "true". (optBoolean ignora números!) */
fun JSONObject.flag(k: String, d: Boolean = false): Boolean = when (val v = opt(k)) {
    is Boolean -> v
    is Number -> v.toInt() != 0
    is String -> v == "true" || v == "1"
    else -> d
}

object Sh {
    @Volatile private var rooted: Boolean? = null

    fun run(cmd: String): String? = try {
        val p = ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor()
        out
    } catch (e: Exception) {
        null
    }

    /** null = ainda não verificado */
    fun peek(): Boolean? = rooted

    fun hasRoot(): Boolean {
        val c = rooted
        if (c != null) return c
        val r = run("id")?.contains("uid=0") == true
        rooted = r
        return r
    }
}

/** Opções salvas no nativo: o app e o ícone flutuante usam as mesmas. */
object Opts {
    private fun p(c: Context) = c.getSharedPreferences("tg", Context.MODE_PRIVATE)

    fun get(c: Context): JSONObject = try {
        JSONObject(p(c).getString("o", "{}") ?: "{}")
    } catch (e: Exception) {
        JSONObject()
    }

    fun set(c: Context, o: JSONObject) {
        p(c).edit().putString("o", o.toString()).apply()
    }

    fun put(c: Context, k: String, v: Any) {
        val o = get(c)
        o.put(k, v)
        set(c, o)
    }
}

/** Ajustes do sistema: funcionam com root OU com a permissão WRITE_SECURE_SETTINGS (concedida 1 vez via adb). */
object Priv {
    fun secure(c: Context): Boolean =
        c.checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == PackageManager.PERMISSION_GRANTED

    fun canSet(c: Context): Boolean = secure(c) || Sh.hasRoot()

    fun putGlobal(c: Context, k: String, v: String): Boolean {
        if (secure(c)) {
            try {
                return Settings.Global.putString(c.contentResolver, k, v)
            } catch (e: Exception) {
            }
        }
        if (Sh.hasRoot()) {
            Sh.run("settings put global $k $v")
            return true
        }
        return false
    }

    fun animOn(c: Context): Boolean {
        val v = try {
            Settings.Global.getString(c.contentResolver, "animator_duration_scale")
        } catch (e: Exception) {
            null
        }
        return (v?.toFloatOrNull() ?: 1f) <= 0.5f
    }

    fun setAnim(c: Context, on: Boolean): Boolean {
        val v = if (on) "0.5" else "1.0"
        val a = putGlobal(c, "window_animation_scale", v)
        val b = putGlobal(c, "transition_animation_scale", v)
        val d = putGlobal(c, "animator_duration_scale", v)
        return a && b && d
    }

    /** A economia de bateria limita a CPU/GPU e derruba o FPS. */
    fun batteryOff(c: Context) {
        val pm = c.getSystemService(Context.POWER_SERVICE) as PowerManager
        if (pm.isPowerSaveMode) putGlobal(c, "low_power", "0")
    }
}

object Sys {
    private fun freeBytes(): Long = StatFs(Environment.getDataDirectory().absolutePath).availableBytes

    fun stats(c: Context): JSONObject {
        val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val b: Intent? = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
        val sc = b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val t = (b?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
        var th = 0
        if (Build.VERSION.SDK_INT >= 29) {
            th = (c.getSystemService(Context.POWER_SERVICE) as PowerManager).currentThermalStatus
        }
        val sf = StatFs(Environment.getDataDirectory().absolutePath)
        return JSONObject()
            .put("ram", (100 * (mi.totalMem - mi.availMem) / mi.totalMem).toInt())
            .put("free", (mi.availMem / 1048576).toInt())
            .put("temp", t)
            .put("bat", 100 * lvl / sc)
            .put("th", th)
            .put("sfree", sf.availableBytes / 1048576)
            .put("stot", sf.totalBytes / 1048576)
    }

    /** Fecha apps em segundo plano. `except` = app que não deve ser tocado (o jogo). */
    fun cleanRam(c: Context, except: String? = null): JSONObject {
        val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val before = mi.availMem
        for (a in c.packageManager.getInstalledApplications(0)) {
            if (a.packageName != c.packageName && a.packageName != except) am.killBackgroundProcesses(a.packageName)
        }
        if (Sh.peek() == true) Sh.run("am kill-all")
        Thread.sleep(1200)
        am.getMemoryInfo(mi)
        return JSONObject()
            .put("mb", maxOf(0L, (mi.availMem - before) / 1048576))
            .put("free", mi.availMem / 1048576)
    }

    /**
     * Limpa o cache de TODOS os apps sem root: pede ao Android o máximo de espaço possível
     * (StorageManager.allocateBytes) e ele apaga os caches para atender. Mede o espaço real liberado.
     */
    fun cleanSys(c: Context): JSONObject {
        val before = freeBytes()
        try {
            val sm = c.getSystemService(Context.STORAGE_SERVICE) as StorageManager
            val uuid = sm.getUuidForPath(c.filesDir)
            val ask = sm.getAllocatableBytes(uuid) - 64L * 1048576
            if (ask > before) sm.allocateBytes(uuid, ask)
        } catch (e: Exception) {
        }
        if (Sh.peek() == true) Sh.run("pm trim-caches 999999999999")
        Thread.sleep(700)
        return JSONObject().put("mb", maxOf(0L, (freeBytes() - before) / 1048576))
    }

    fun cleanOwn(c: Context): Long {
        var n = 0L
        for (d in listOf(c.cacheDir, c.externalCacheDir)) {
            if (d != null) {
                for (f in d.walkTopDown()) if (f.isFile) n += f.length()
                d.listFiles()?.forEach { it.deleteRecursively() }
            }
        }
        return n / 1048576
    }
}
