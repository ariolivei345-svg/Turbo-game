package com.turbo.game

import android.Manifest
import android.app.Activity
import android.app.NotificationManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionConfig
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var pending: Pending? = null

    private class Pending(val pkg: String, val name: String, val o: JSONObject, val li: Intent, val root: Boolean)

    private val OK = "{\"ok\":true}"

    private fun open(a: String, u: String?) {
        val i = Intent(a)
        if (u != null) i.data = Uri.parse(u)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runOnUiThread { startActivity(i) }
    }

    private fun js(code: String) {
        runOnUiThread { if (::web.isInitialized) web.evaluateJavascript(code, null) }
    }

    private fun bg(f: () -> Unit) {
        Thread {
            try {
                f()
            } catch (e: Exception) {
            }
        }.start()
    }

    /** Prepara o aparelho, sobe o ícone flutuante (com a captura de FPS, se houver) e abre o app. */
    private fun go(p: Pending, code: Int, data: Intent?) {
        val o = p.o
        bg {
            if (o.flag("ram")) Sys.cleanRam(this, p.pkg)
            if (o.flag("cache")) Sys.cleanSys(this)
            if (o.flag("bat") && Priv.canSet(this)) Priv.batteryOff(this)
            if (p.root) {
                if (o.flag("perf")) Sh.run("cmd game mode performance ${p.pkg}")
                if (o.flag("comp")) bg { Sh.run("cmd package compile -m speed-profile -f ${p.pkg}") }
            }
            runOnUiThread {
                if (o.flag("ov", true)) {
                    if (data != null) {
                        startForegroundService(
                            Intent(this, CaptureService::class.java).putExtra("code", code).putExtra("data", data)
                        )
                    }
                    startForegroundService(
                        Intent(this, OverlayService::class.java)
                            .putExtra("pkg", p.pkg)
                            .putExtra("name", p.name)
                            .putExtra("awake", o.flag("awake"))
                            .putExtra("dnd", o.flag("dnd"))
                            .putExtra("perf", o.flag("perf") && p.root)
                            .putExtra("fps", o.flag("fps", true))
                            .putExtra("root", p.root)
                            .putExtra("heat", o.optInt("heat", 0))
                    )
                }
                startActivity(p.li)
            }
        }
    }

    inner class Bridge {
        /** Todos os apps que têm ícone na tela inicial; jogos primeiro. [nome, pacote, éJogo] */
        @JavascriptInterface
        fun apps(): String {
            val pm = packageManager
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val seen = HashSet<String>()
            val list = ArrayList<Triple<String, String, Boolean>>()
            for (r in pm.queryIntentActivities(q, 0)) {
                val ai = r.activityInfo.applicationInfo
                val p = ai.packageName
                if (p == packageName || !seen.add(p)) continue
                @Suppress("DEPRECATION")
                val g = (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0 || ai.category == ApplicationInfo.CATEGORY_GAME
                list.add(Triple(r.loadLabel(pm).toString(), p, g))
            }
            list.sortWith(compareBy<Triple<String, String, Boolean>>({ !it.third }, { it.first.lowercase() }))
            val out = JSONArray()
            list.forEach { out.put(JSONArray().put(it.first).put(it.second).put(it.third)) }
            return out.toString()
        }

        @JavascriptInterface
        fun stats(): String = Sys.stats(this@MainActivity).toString()

        @JavascriptInterface
        fun getOpts(): String = Opts.get(this@MainActivity).toString()

        @JavascriptInterface
        fun setOpts(s: String): String {
            try {
                Opts.set(this@MainActivity, JSONObject(s))
            } catch (e: Exception) {
            }
            return OK
        }

        @JavascriptInterface
        fun root(): String = (Sh.peek() == true).toString()

        /** Estado real de tudo que o app precisa. root = null enquanto ainda verifica. */
        @JavascriptInterface
        fun priv(): String {
            val c = this@MainActivity
            val nm = getSystemService(NotificationManager::class.java)
            val notif = if (Build.VERSION.SDK_INT >= 33)
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED else true
            val o = JSONObject()
            o.put("root", Sh.peek() ?: JSONObject.NULL)
            o.put("secure", Priv.secure(c))
            o.put("overlay", Settings.canDrawOverlays(c))
            o.put("dnd", nm.isNotificationPolicyAccessGranted)
            o.put("notif", notif)
            o.put("anim", Priv.animOn(c))
            return o.toString()
        }

        @JavascriptInterface
        fun openPerm(k: String): String {
            when (k) {
                "overlay" -> open(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, "package:$packageName")
                "dnd" -> open(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS, null)
                "notif" -> runOnUiThread {
                    if (Build.VERSION.SDK_INT >= 33) {
                        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 5)
                    } else {
                        startActivity(
                            Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                                .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                        )
                    }
                }
            }
            return OK
        }

        @JavascriptInterface
        fun setAnim(on: Boolean): String {
            val ok = Priv.canSet(this@MainActivity) && Priv.setAnim(this@MainActivity, on)
            return JSONObject().put("ok", ok).toString()
        }

        @JavascriptInterface
        fun cleanRam(): String {
            bg {
                val r = Sys.cleanRam(this@MainActivity)
                js("onDone('ram',$r)")
            }
            return OK
        }

        @JavascriptInterface
        fun cleanSys(): String {
            bg {
                val r = Sys.cleanSys(this@MainActivity)
                js("onDone('sys',$r)")
            }
            return OK
        }

        @JavascriptInterface
        fun cleanAll(): String {
            bg {
                val r = Sys.cleanRam(this@MainActivity)
                val s = Sys.cleanSys(this@MainActivity)
                val own = Sys.cleanOwn(this@MainActivity)
                val o = JSONObject().put("ram", r.optLong("mb")).put("sys", s.optLong("mb")).put("own", own)
                js("onDone('all',$o)")
            }
            return OK
        }

        @JavascriptInterface
        fun cleanOwn(): String = JSONObject().put("mb", Sys.cleanOwn(this@MainActivity)).toString()

        @JavascriptInterface
        fun copy(t: String): String {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            runOnUiThread { cm.setPrimaryClip(ClipData.newPlainText("codigo", t)) }
            return "true"
        }

        @JavascriptInterface
        fun runCode(id: String): String {
            val c = this@MainActivity
            val need = "{\"ok\":false,\"need\":\"root\"}"
            when (id) {
                "anim", "anim0" -> {
                    if (!Priv.canSet(c)) return "{\"ok\":false,\"need\":\"adv\"}"
                    bg {
                        Priv.setAnim(c, id == "anim")
                        js("sync()")
                    }
                    return OK
                }
                "kill" -> {
                    bg {
                        val r = Sys.cleanRam(c)
                        js("toast('${r.optLong("mb")} MB de RAM liberados')")
                    }
                    return OK
                }
                "trim" -> {
                    bg {
                        val r = Sys.cleanSys(c)
                        js("toast('${r.optLong("mb")} MB de cache liberados')")
                    }
                    return OK
                }
            }
            val cmd = when (id) {
                "dex" -> "cmd package compile -m speed-profile -a"
                "bg" -> "cmd package bg-dexopt-job"
                "idle" -> "sm idle-maint run"
                else -> return "{\"ok\":false}"
            }
            if (!Sh.hasRoot()) return need
            bg { Sh.run(cmd) }
            return OK
        }

        @JavascriptInterface
        fun clearCache(pkg: String): String {
            if (Sh.peek() == true) {
                bg { Sh.run("rm -rf /data/data/$pkg/cache/* /data/data/$pkg/code_cache/* /sdcard/Android/data/$pkg/cache/*") }
                return OK
            }
            open(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, "package:$pkg")
            return "{\"ok\":false}"
        }

        @JavascriptInterface
        fun launch(pkg: String, name: String, opts: String): String {
            val c = this@MainActivity
            val o = JSONObject(opts)
            val useOv = o.flag("ov", true)
            if (useOv && !Settings.canDrawOverlays(c)) {
                open(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, "package:$packageName")
                return "{\"ok\":false,\"need\":\"overlay\"}"
            }
            val nm = getSystemService(NotificationManager::class.java)
            if (o.flag("dnd") && !nm.isNotificationPolicyAccessGranted) {
                open(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS, null)
                return "{\"ok\":false,\"need\":\"dnd\"}"
            }
            val li = packageManager.getLaunchIntentForPackage(pkg) ?: return "{\"ok\":false,\"need\":\"nolaunch\"}"
            li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            val root = Sh.peek() == true
            val p = Pending(pkg, name, o, li, root)
            // Sem root, o FPS real vem da captura de tela: o Android pede autorização a cada abertura
            if (useOv && o.flag("fps", true) && !root) {
                pending = p
                val mpm = getSystemService(MediaProjectionManager::class.java)
                val sci = if (Build.VERSION.SDK_INT >= 34)
                    mpm.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay())
                else mpm.createScreenCaptureIntent()
                runOnUiThread { startActivityForResult(sci, 77) }
                return "{\"ok\":true,\"wait\":true}"
            }
            go(p, 0, null)
            return OK
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(rq: Int, rc: Int, d: Intent?) {
        super.onActivityResult(rq, rc, d)
        if (rq != 77) return
        val p = pending ?: return
        pending = null
        if (rc == RESULT_OK && d != null) {
            go(p, rc, d)
        } else {
            js("toast('Sem autorização de captura: o FPS real não vai aparecer')")
            go(p, 0, null)
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val w = WebView(this)
        web = w
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.addJavascriptInterface(Bridge(), "TG")
        w.loadUrl("file:///android_asset/index.html")
        setContentView(w)
        // verifica o root em segundo plano (o pedido do Magisk não trava a tela)
        bg {
            Sh.hasRoot()
            js("window.sync&&sync()")
        }
    }

    override fun onResume() {
        super.onResume()
        js("window.sync&&sync()")
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        moveTaskToBack(true)
    }
}
