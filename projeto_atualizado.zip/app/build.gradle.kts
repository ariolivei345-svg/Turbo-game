plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
  signingConfigs { getByName("debug") { storeFile = file("debug.keystore"); storePassword = "android"; keyAlias = "androiddebugkey"; keyPassword = "android" } }
  namespace = "com.turbo.game"
  compileSdk = 34
  defaultConfig { applicationId = "com.turbo.game"; minSdk = 26; targetSdk = 33; versionCode = 1; versionName = "1.0" }
  compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
  kotlinOptions { jvmTarget = "17" }
}
